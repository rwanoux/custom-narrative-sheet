let defaultTooltips = {

    masterRelation: "Texte défault relation au maitre",
    souvenir: "Texte défault souvenir",
    liens: "Texte défault liens",
    liensForce: "Texte défault lien avec la force",
    rites: "Texte défault rites"

}

export default defaultTooltips