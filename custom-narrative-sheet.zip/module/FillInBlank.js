export default class FillInBlank {
    contructor() {
        this.readableText = "test de test de test";
        this.blanksIndex = [];
    }
}